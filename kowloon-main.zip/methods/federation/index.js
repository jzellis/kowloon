import shouldFederate from "./shouldFederate.js";
export default { shouldFederate };
