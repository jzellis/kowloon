import get from "./get.js";

export default { get };
