import get from "./get.js";
import list from "./list.js";

export default { get, list };
