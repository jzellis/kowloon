// #methods/get/getVisibleById.js
import {
  Activity,
  Bookmark,
  Circle,
  Event,
  File,
  Flag,
  Group,
  Page,
  Post,
  React,
  Reply,
  User,
  Invite,
} from "#schema";
import { getViewerContext } from "#methods/visibility/context.js";
import { buildVisibilityQuery } from "#methods/visibility/filter.js";
import { sanitizeAudience } from "#methods/visibility/helpers.js";

/** map objectType -> model */
const MODEL = {
  activity: Activity,
  bookmark: Bookmark,
  circle: Circle,
  event: Event,
  file: File,
  flag: Flag,
  group: Group,
  page: Page,
  post: Post,
  react: React,
  reply: Reply,
  user: User,
  invite: Invite,
};

/** same projector we use in the collection function */
function buildProjection(select) {
  if (!select) return "-_id -__v";
  const sel = Array.isArray(select)
    ? select.join(" ")
    : String(select).replace(/,/g, " ").trim();
  if (!sel) return "-_id -__v";
  const tokens = sel.split(/\s+/);
  const isInclusion = tokens.every((t) => !t.startsWith("-"));
  return isInclusion ? `${sel} -_id` : `-__v -_id ${sel}`;
}

/**
 * Get a single visible object by id, enforcing visibility for viewerId.
 *
 * @param {"post"|"event"|"group"|...} objectType
 * @param {string} id                  // full Kowloon id
 * @param {object} opts
 * @param {string|null} opts.viewerId
 * @param {string|string[]} [opts.select]
 * @param {boolean} [opts.deleted=false]
 * @param {boolean} [opts.maskAudience=true]
 * @returns {Promise<object|null>}     // null if not visible
 */
export default async function getVisibleById(objectType, id, opts = {}) {
  const { viewerId, select, deleted = false, maskAudience = true } = opts;

  const Model = MODEL[(objectType || "").toLowerCase()];
  if (!Model) throw new Error(`Unknown object type: ${objectType}`);
  if (!id || typeof id !== "string") throw new Error("Missing id");

  // Viewer context & visibility filter
  const ctx = await getViewerContext(viewerId);
  const vis = buildVisibilityQuery(ctx);

  // Combine: target id + visibility + not deleted (unless allowed)
  const filter = { id, ...(deleted ? {} : { deletedAt: null }), ...vis };

  const doc = await Model.findOne(filter)
    .select(buildProjection(select))
    .lean();
  if (!doc) return null;

  return maskAudience ? sanitizeAudience(doc, ctx) : doc;
}
