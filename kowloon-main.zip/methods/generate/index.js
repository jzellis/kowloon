import token from "./token.js";
import password from "./password.js";

export default { token, password };
