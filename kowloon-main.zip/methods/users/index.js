import get from "./get.js";
import memberships from "./memberships.js";
import list from "./list.js";

export default { get, memberships, list };
