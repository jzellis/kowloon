import get from "./get.js";
import admins from "./admins.js";
import editors from "./editors.js";
export default { get, admins, editors };
