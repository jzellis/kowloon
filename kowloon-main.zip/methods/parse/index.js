import isLocalDomain from "./isLocalDomain.js";
import parseKowloonId from "./parseKowloonId.js";

export default { isLocalDomain, parseKowloonId };
