import __nukeDb from "./__nukeDb.js";
import assertTypeFromId from "./assertTypeFromId.js";
import init from "./init.js";

export default {
  __nukeDb,
  assertTypeFromId,
  init,
};
