export default async function (activity) {
  return activity;
}
