import "dotenv/config";
import "#kowloon"; // this import boots the singleton, which runs init() and starts the server
