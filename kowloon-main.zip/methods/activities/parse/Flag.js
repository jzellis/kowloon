import getObjectById from "#methods/get/objectById.js";
import { User } from "#schema";
export default async function (activity) {
  return activity;
}
