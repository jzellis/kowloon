// /Kowloon.js
import "dotenv/config";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// The singleton object we’ll populate and export
const Kowloon = {
  settings: {},
  connection: null, // actual mongoose.connection will be attached by utils.init
  mongoose: null, // mongoose instance (attached by utils.init)
  routes: {}, // name -> express.Router
  routeMeta: {}, // name -> { mountPath, module }
  reservedUsernames: ["admin", "kowloon", "public"],
};

// ------------ helpers to load method domains (Kowloon.get, Kowloon.utils, etc.) ------------
async function attachMethodDomains(target) {
  const methodsDir = path.join(__dirname, "methods");
  let entries = [];
  try {
    entries = fs.readdirSync(methodsDir, { withFileTypes: true });
  } catch {
    console.warn("Kowloon: no /methods directory found");
    return;
  }

  for (const ent of entries) {
    if (!ent.isDirectory()) continue;
    const name = ent.name; // e.g. "get", "parse", "settings", "utils"
    const indexPath = path.join(methodsDir, name, "index.js");
    if (!fs.existsSync(indexPath)) continue;

    try {
      const mod = await import(pathToFileURL(indexPath).href);
      // Prefer default export (object of functions). If absent, attach the module namespace.
      const ns =
        mod && mod.default && typeof mod.default === "object"
          ? mod.default
          : mod;
      target[name] = ns;
      console.log(`Kowloon: methods loaded -> ${name}`);
    } catch (e) {
      console.error(`Kowloon: failed loading methods/${name}:`, e);
    }
  }
}

// ------------------- helpers to load route modules into Kowloon.routes ---------------------
async function attachRouteDomains(target) {
  const routesDir = path.join(__dirname, "routes");
  let entries = [];
  try {
    entries = fs.readdirSync(routesDir, { withFileTypes: true });
  } catch {
    console.warn("Kowloon: no /routes directory found");
    return;
  }

  target.routes = {};
  target.routeMeta = {};

  for (const ent of entries) {
    if (!ent.isDirectory()) continue;

    const name = ent.name; // e.g. "posts", "users", "resolve", "well-known"
    if (name === "middleware" || name === "utils") continue;

    const indexPath = path.join(routesDir, name, "index.js");
    if (!fs.existsSync(indexPath)) {
      console.log(`Kowloon: skip routes/${name} (no index.js)`);
      continue;
    }

    try {
      const mod = await import(pathToFileURL(indexPath).href);
      const router = mod?.default || mod?.router;
      if (typeof router !== "function") {
        console.warn(
          `Kowloon: routes/${name} default export is not a router; skipping`
        );
        continue;
      }

      const mountPath =
        name === "home"
          ? "/"
          : name === "well-known"
          ? "/.well-known"
          : `/${name}`;

      target.routes[name] = router;
      target.routeMeta[name] = { mountPath, module: mod };
      console.log(`Kowloon: route registered ${mountPath}`);
    } catch (e) {
      console.error(`Kowloon: failed loading routes/${name}:`, e);
    }
  }
}

// ---------------------------------- boot sequence -----------------------------------------
const ctx = {
  domain: process.env.DOMAIN || undefined,
  siteTitle: process.env.SITE_TITLE || "Kowloon",
  adminEmail: process.env.ADMIN_EMAIL || undefined,
  smtpHost: process.env.SMTP_HOST || undefined,
  smtpUser: process.env.SMTP_USER || undefined,
  smtpPass: process.env.SMTP_PASS || undefined,
};

await attachMethodDomains(Kowloon);
await attachRouteDomains(Kowloon);

// utils can be a default FUNCTION or an object with .init — support both.
if (Kowloon.utils) {
  if (typeof Kowloon.utils === "function") {
    await Kowloon.utils(Kowloon, ctx);
  } else if (typeof Kowloon.utils.init === "function") {
    await Kowloon.utils.init(Kowloon, ctx);
  } else {
    console.warn("Kowloon: utils initializer not found; skipping init()");
  }
} else {
  console.warn("Kowloon: no utils domain found; skipping init()");
}

export default Kowloon;
