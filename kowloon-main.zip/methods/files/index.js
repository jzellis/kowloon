import get from "./get.js";
import list from "./list.js";

import StorageAdapter from "./StorageAdapter/StorageAdapter.js";
export default { get, list };
