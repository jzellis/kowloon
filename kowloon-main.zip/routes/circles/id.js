import route from "../utils/route.js";
import objectById from "#methods/get/objectById.js";

export default route(async ({ req, params, query, set, setStatus }) => {
  const id = decodeURIComponent(params.id);
  const select = query.select; // optional projection

  const item = await getVisibleById("circle", id, {
    viewerId: req.user?.id || null,
    select,
  });

  if (!item) {
    setStatus(404);
    set("error", "Not found");
    return;
  }

  set("item", item);
});
