import get from "./get.js";
import buildTree from "./buildTree.js";
import list from "./list.js";

export default { get, buildTree, list };
