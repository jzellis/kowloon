// routes/pages/id.js
import route from "../utils/route.js";
import objectById from "#methods/get/objectById.js";

export default route(async ({ req, params, set, setStatus }) => {
  const id = decodeURIComponent(params.id);
  const item = await getVisibleById("page", id, {
    viewerId: req.user?.id || null,
  });
  if (!item) {
    setStatus(404);
    set("error", "Page not found or not visible");
    return;
  }
  set("item", item);
});
