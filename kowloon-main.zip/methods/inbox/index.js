import get from "./get.js";
import parse from "./parse/index.js";
import process from "./process.js";
import getFeed from "./getFeed.js";

export default { get, parse, process, getFeed };
